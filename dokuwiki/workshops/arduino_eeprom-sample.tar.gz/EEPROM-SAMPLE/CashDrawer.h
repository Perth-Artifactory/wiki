/*
 CashDrawer Server

 Copyright (C) 2012 Bernd Felsche, Innovative Reckoning,
 	Perth, Western Australia

 EEPROM map. multi-byte data checksum low byte of sum(odd)+2*sum(even)

*/

/* dictionary entries consist of
 * PAGE MARKER byte=0 byte=page 8bytes=label
 * Detail 2byte=label 2byte=address byte=type:length
 * Internal data types for compression 
 * of type and length to conserve EEPROM 
 * dictionary
 *
 * TODO: Store backup defaults in dictionary for dynamic
 *       recovery from stuffed-up configuration in EEPROM.
 *       (There is *just* enough space in 1kbyte EEPROM)
 */

/*
 * There are a few data types. Eight (8)
 *
 * Each data element can contain up to 15 bytes (4 bit size)
 * The space consumed by a multi-byte element includes the
 * single-byte checksum stored along with the value.
 *
 * There is one "protection bit" to block
 * runtime firmware from changing that value.
 *
 * The protection flag is set on the high bit of the first
 * label character.
 *
 * The attributes are packed into one byte in the dictionary
 *    type bits 4-7
 *    size bits 0-3
 */

// types
#define et_BIT	0	// a bit-pattern in a byte
#define et_IP	1	// an IPAddress (IPv4) 4 bytes + chksum
#define et_MAC	2	// MAC number 6 bytes + checksum
#define et_UINT	3	// unsigned integer 16-bits + checksum
#define et_INT	4	// signed integer 16-bits + checksum
#define et_CHR	5	// single character in a byte
#define et_BYT	6	// a number in a byte
#define et_STR	7	// a character array (string) n-bytes + chksum

// Base Page
#define EEbase    0
#define NetMAGIC  170		// magic value (binary 10101010)
#define SerialScale	1200	// baud scaling factor
#define l_EEbase	"SysBase"	// Base page
#define m_EEbase	'S'		// index page/menu ID
#define Version		EEbase+1	// 1 byte version number
#define l_Version	"VR"		// index label within page
#define ll_Version	"Version"	// long label
#define t_Version	et_BYT		// data type
#define p_Version	true		// block run-time config change
#define s_Version	1		// length in EEPROM
#define Revision	Version+1	// 1 byte revision number
#define l_Revision	"RV"
#define ll_Revision	"Revision"
#define t_Revision	et_BYT
#define p_Revision	true
#define s_Revision	1
#define Release		Revision+1	// 1 byte release number
#define l_Release	"RL"
#define ll_Release	"Release"
#define t_Release	et_BYT
#define p_Release	true
#define s_Release	1
#define SerialSpd	Release+1	// 1 byte serial speed / 1200 (0=>300)
#define l_SerialSpd	"BD"
#define ll_SerialSpd	"Ser.Baud"
#define t_SerialSpd et_BYT
#define p_SerialSpd false
#define s_SerialSpd 1

// Network basic page
#define Netbase   SerialSpd+1	// basic network conf
#define l_Netbase	"BaseNet"
#define m_Netbase	'B'
#define MyMAC     SerialSpd+1   // 6 bytes + checksum
#define l_MyMAC	"MM"
#define ll_MyMAC	"My MAC"
#define t_MyMAC	et_MAC
#define	p_MyMAC	true	// don't change in runtime firmware	
#define	s_MyMAC	7
#define MyIPdhcp  MyMAC+7     // Y/N
#define l_MyIPdhcp	"ID"
#define ll_MyIPdhcp	"DHCP IP"
#define t_MyIPdhcp	et_CHR
#define p_MyIPdhcp	false
#define s_MyIPdhcp	1
#define MyIP      MyIPdhcp+1  // 4 bytes + checksum
#define l_MyIP	"IM"
#define ll_MyIP	"Def IP"
#define t_MyIP	et_IP
#define p_MyIP	false
#define s_MyIP	5
#define MyNetMask MyIP+5      // 1 byte as bitmap length in bits
#define l_MyNetMask	"NM"
#define ll_MyNetMask	"Subnet"
#define t_MyNetMask	et_BYT
#define p_MyNetMask	false
#define s_MyNetMask	1
#define MyGwIP    MyNetMask+1 // 4 bytes + checksum
#define l_MyGwIP	"GW"
#define ll_MyGwIP	"Gateway"
#define t_MyGwIP	et_IP
#define p_MyGwIP	false
#define s_MyGwIP	5
#define MyDnsSrv  MyGwIP+5    // 4 bytes + checksum
#define l_MyDnsSrv	"DN"
#define ll_MyDnsSrv	"DNS Srvr"
#define t_MyDnsSrv	et_IP
#define p_MyDnsSrv	false
#define s_MyDnsSrv	5
#define MyUdpPort MyDnsSrv+5  // UDP port for DHCP, NTP, syslog
#define l_MyUdpPort	"MU"
#define ll_MyUdpPort	"UDP port"
#define t_MyUdpPort	et_UINT
#define p_MyUdpPort	false
#define s_MyUdpPort	3
#define MyIPend   MyUdpPort+3

// NTP Page
#define SNTPsrv     MyIPend
#define l_SNTPsrv	"NTPsrv"
#define m_SNTPsrv	'N'
#define SNTPdhcp    SNTPsrv       // Y/N
#define l_SNTPdhcp	"ND"
#define ll_SNTPdhcp	"DHCP?"
#define t_SNTPdhcp	et_CHR
#define p_SNTPdhcp	false
#define s_SNTPdhcp	1
#define l_MyIPend	
#define SNTPsrvIP   SNTPdhcp+1    // 4 bytes + checksum
#define l_SNTPsrvIP	"NI"
#define ll_SNTPsrvIP	"NTP IP"
#define t_SNTPsrvIP	et_IP
#define p_SNTPsrvIP	false
#define s_SNTPsrvIP	5
#define SNTPsrvPort SNTPsrvIP+5   // NTP port (2 bytes + checksum)
#define l_SNTPsrvPort	"NP"
#define ll_SNTPsrvPort	"NTP port"
#define t_SNTPsrvPort	et_UINT
#define p_SNTPsrvPort	false
#define s_SNTPsrvPort	3
#define UTCoffset   SNTPsrvPort+3 // GMT/UTC offset in minutes (signed int)
#define l_UTCoffset	"TZ"
#define ll_UTCoffset	"Minutes"
#define t_UTCoffset	et_INT
#define p_UTCoffset	false
#define s_UTCoffset	3
#define SNTPtryDNS  UTCoffset+3   // DNS srv for NTP (0=never,1=before pub,2=after)
#define l_SNTPtryDNS	"NS"
#define ll_SNTPtryDNS	"DNS NTP"
#define t_SNTPtryDNS	et_BYT
#define p_SNTPtryDNS	false
#define s_SNTPtryDNS	1
#define SNTPpubNum  SNTPtryDNS+1  // Max known public NTP servers to follow 1 byte
#define l_SNTPpubNum	"NN"
#define ll_SNTPpubNum	"#Pub NTP"
#define t_SNTPpubNum	et_BYT
#define p_SNTPpubNum	true	// mustn't allow the unwashed to tamper
#define s_SNTPpubNum	1
#define SNTPpub0    SNTPpubNum+1  // Primary public NTP server (4 bytes + checksum)
#define l_SNTPpub0	"N0"
#define ll_SNTPpub0	"Pub NTP0"
#define t_SNTPpub0	et_IP
#define p_SNTPpub0	false
#define s_SNTPpub0	5
#define SNTPpub1    SNTPpub0+5    // Other public NTP server (4 bytes + checksum)
#define l_SNTPpub1	"N1"
#define ll_SNTPpub1	"Pub NTP1"
#define t_SNTPpub1	et_IP
#define p_SNTPpub1	false
#define s_SNTPpub1	5
#define SNTPpub2    SNTPpub1+5    // Other public NTP server (4 bytes + checksum)
#define l_SNTPpub2	"N2"
#define ll_SNTPpub2	"Pub NTP2"
#define t_SNTPpub2	et_IP
#define p_SNTPpub2	false
#define s_SNTPpub2	5
#define SNTPpub3    SNTPpub2+5    // Other public NTP server (4 bytes + checksum)
#define l_SNTPpub3	"N3"
#define ll_SNTPpub3	"Pub NTP3"
#define t_SNTPpub3	et_IP
#define p_SNTPpub3	false
#define s_SNTPpub3	5
#define SNTPsrvEnd  SNTPpub3+5

// Syslog Page
#define LogSrv      SNTPsrvEnd
#define l_LogSrv	"Syslog"
#define m_LogSrv	'L'
#define LogSrvDhcp  LogSrv        // Y/N
#define l_LogSrvDhcp	"DH"
#define ll_LogSrvDhcp	"DHCP"
#define t_LogSrvDhcp	et_CHR
#define p_LogSrvDhcp	false
#define s_LogSrvDhcp	1
#define LogSrvIP    LogSrvDhcp+1  // 4 bytes + checksum
#define l_LogSrvIP	"SL"
#define ll_LogSrvIP	"IP"
#define t_LogSrvIP	et_IP
#define p_LogSrvIP	false
#define s_LogSrvIP	5
#define LogSrvPort  LogSrvIP+5    // syslog port + checksum
#define l_LogSrvPort	"LP"
#define ll_LogSrvPort	"Log port"
#define t_LogSrvPort	et_UINT
#define p_LogSrvPort	false
#define s_LogSrvPort	3
#define LogSrvEnd   LogSrvPort+3

#define SysLog       LogSrvEnd     // Syslog parameters
#define SysFacility  SysLog        // Facility code
#define l_SysFacility	"FC"
#define ll_SysFacility	"Facility"
#define t_SysFacility	et_BYT
#define p_SysFacility	false
#define s_SysFacility	1
#define SysAlarm     SysFacility+1 // Severity on cable break, etc (=2)
#define l_SysAlarm	"AL"
#define ll_SysAlarm	"AlarmSev"
#define t_SysAlarm	et_BYT
#define p_SysAlarm	false
#define s_SysAlarm	1
#define SysWarn      SysAlarm+1    // Severity on Drawer Open by key (=4)
#define l_SysWarn	"WN"
#define ll_SysWarn	"WarnSev"
#define t_SysWarn	et_BYT
#define p_SysWarn	false
#define s_SysWarn	1
#define SysNormal    SysWarn+1     // Severity on commended drawer open (=5)
#define l_SysNormal	"NR"
#define ll_SysNormal	"NormSev"
#define t_SysNormal	et_BYT
#define p_SysNormal	false
#define s_SysNormal	1
#define SysInfo      SysNormal+1   // Severity for information (boot and NTP) (=6)
#define l_SysInfo	"IN"
#define ll_SysInfo	"InfoSev"
#define t_SysInfo	et_BYT
#define p_SysInfo	false
#define s_SysInfo	1
#define SysName      SysInfo+1     // 8-byte name (null padded) + checksum
#define l_SysName	"HN"
#define ll_SysName	"Hostname"
#define t_SysName	et_STR
#define p_SysName	false
#define s_SysName	9
#define SysLogEnd    SysName+9

// Drawers Page
#define Drawers        SysLogEnd     // base of drawers
#define l_Drawers	"Drawer"
#define m_Drawers	'D'
#define DrawerInst	Drawers+1     // bitmap of drawers installed
#define l_DrawerInst	"DI"
#define ll_DrawerInst	"Installd"
#define t_DrawerInst	et_BIT
#define p_DrawerInst	false
#define s_DrawerInst	1
#define DrawerSwitches	DrawerInst+1 // bitmap of drawer microswitches to monitor
#define l_DrawerSwitches	"DS"
#define ll_DrawerSwitches	"Switches"
#define t_DrawerSwitches	et_BIT
#define p_DrawerSwitches	false
#define s_DrawerSwitches	1
#define BeepOpen	DrawerSwitches+1 // bitmap to beep which drawer open
#define l_BeepOpen	"BP"
#define ll_BeepOpen	"BeepOpen"
#define t_BeepOpen	et_BIT
#define p_BeepOpen	false
#define s_BeepOpen	1
#define KeyOpen        BeepOpen+1    // bitmap of drawers to watch for key open
#define l_KeyOpen	"KO"
#define ll_KeyOpen	"KeyOpen"
#define t_KeyOpen	et_BIT
#define p_KeyOpen	false
#define s_KeyOpen	1
#define RemindClose    KeyOpen+1     // bitmap of reminder to close
#define l_RemindClose	"RC"
#define ll_RemindClose	"RemClose"
#define t_RemindClose	et_BIT
#define p_RemindClose	false
#define s_RemindClose	1
#define RemindDelay    RemindClose+1 // number of seconds before reminder (<10 disables)
#define l_RemindDelay	"RD"
#define ll_RemindDelay	"RemDelay"
#define t_RemindDelay	et_BYT
#define p_RemindDelay	false
#define s_RemindDelay	1
#define AlarmCable     RemindDelay+1 // bitmap of cables to monitor
#define l_AlarmCable	"CB"
#define ll_AlarmCable	"CableErr"
#define t_AlarmCable	et_BIT
#define p_AlarmCable	false
#define s_AlarmCable	1
#define DrawersEnd     AlarmCable+1

// Command Server Page
#define CtrlSrv     DrawersEnd    // Control Server
#define l_CtrlSrv	"CtrlSrvr"
#define m_CtrlSrv	'C'
#define CtrlSrvIP   CtrlSrv       // Control Server's IP 4 bytes + checksum
#define l_CtrlSrvIP	"CS"
#define ll_CtrlSrvIP	"Command"
#define t_CtrlSrvIP	et_IP
#define p_CtrlSrvIP	false
#define s_CtrlSrvIP	5
#define CtrlSrvMAC  CtrlSrv+5     // Control Server's MAC ID
#define l_CtrlSrvMAC	"CM"
#define ll_CtrlSrvMAC	"Cmd MAC"
#define t_CtrlSrvMAC	et_MAC
#define p_CtrlSrvMAC	false
#define s_CtrlSrvMAC	7
#define CtrlSrvPort CtrlSrvMAC+7  // port number (2 bytes) + checksum
#define l_CtrlSrvPort	"PT"
#define ll_CtrlSrvPort	"Cmd port"
#define t_CtrlSrvPort	et_UINT
#define p_CtrlSrvPort	false
#define s_CtrlSrvPort	3
#define MyListen    CtrlSrvPort+3 // port number + checksum
#define l_MyListen	"LS"
#define ll_MyListen	"ListenPt"
#define t_MyListen	et_UINT
#define p_MyListen	false
#define s_MyListen	3
#define CtrlEnd     MyListen+3

#define EEend	   CtrlEnd // End of the world.

// FACTORY Default Space
#define FDefault	EEend	// Base address of EEPROM Factory default storage
#define FDefEnd		FDefault+EEend-EEbase

// Data Dictionary
#define DictBase	FDefEnd	// all above here can get zapped

#define EEtop	1024	// After Last address
