/*

 String constants to be stored in program flash

 Copyright (C) 2012 Bernd Felsche, Innovative Reckoning,
 	Perth, Western Australia

*/

PROGMEM const char BannerLine[] =
  "------------------------------------------------\n";
PROGMEM const char BannerDollar[] =
  "\n$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n";
PROGMEM const char Banner1[] = "\n\tCashDrawer Server EEPROM Manager\n";
PROGMEM const char Banner1r[] = "\n\tCashDrawer Server\n";
PROGMEM const char Banner1m[] = "\n\tCashDrawer MegaServer\n";
PROGMEM const char Banner2[] = ""; //"\n\tCOPYRIGHT NOTICE\n";
PROGMEM const char Banner3[] =
  "\n\tCopyright (C) 2012 Bernd Felsche,\n";
PROGMEM const char Banner4[] =
  "\tInnovative Reckoning, Perth, Western Australia\n";
PROGMEM const char Banner5[] =
  "\tALL RIGHTS RESERVED\n\n";
PROGMEM const char Banner6[] =
  "\tThis in an unpublished work\n\n";

#define STR_HELPER(x) #x
#define STR(x) STR_HELPER(x)

PROGMEM const char FWlabel[] = "Firmware version:";
PROGMEM const char FWnumber[] =
  STR(ThisVersion) "." STR(ThisRevision) "." STR(ThisRelease);
PROGMEM const char FWcompDate[] = __DATE__;

PROGMEM const char MainHelp[] =
  "\nMenu Navigation:\n\t^ Main Menu\n\t";
PROGMEM const char MainHelp1[] =
  ". Show Current\n\t< Back one Level\n\n";

PROGMEM const char MainMenuHdr[] = "\n\nMain Menu\n";
PROGMEM const char MainMenuC[] =   "C) Copyright/Version\n";
PROGMEM const char MainMenuV[] =   "V) Show Dynamic Variables\n";
PROGMEM const char MainMenuP[] =   "P) Pages Menu\n";
PROGMEM const char MainMenuD[] =   "D) Dump EEPROM Map\n";
PROGMEM const char MainMenuR[] =   "R) Reset ALL settings to Factory\n";
PROGMEM const char MainMenuI[] =   "I) Initialise Factory Defaults\n";
PROGMEM const char MainMenuB[] =   "B) Burn Data Dictionary\n";
PROGMEM const char MainMenuZ[] =   "Z) Zap ALL EEPROM\n";

PROGMEM const char PagesMenuHdr[] = "\n\nPages Menu\n";
PROGMEM const char NoDictionary[] =
  "\n\tNo dictionary loaded.\n\tLoad one using the EE Manager.\n";

PROGMEM const char SettingsMenuHdr[] = " Settings Menu\n";

PROGMEM const char EntryMenuHdr[] = "\n\nEntry Detail\n";
PROGMEM const char EntryMenuS[] = "S) Set Value\n";
PROGMEM const char EntryMenuR[] = "R) Reset to Factory Default\n";

PROGMEM const char EntrySettingHdr[] = "\n\nEntry Setting\n";
PROGMEM const char EntrySettingWARN[] =
	"\n\tWARNING: CONSULT MANUAL BEFORE CHANGES\n";
PROGMEM const char EntryWARN1[] = 
  "\n\tThe device may become inoperable if settings are incorrect.\n";
PROGMEM const char EntryWARN2[] = "";

PROGMEM const char EntryResetHdr1[] = "\n\nReset Entry to Factory Default\n";
PROGMEM const char EntryResetHdr2[] = "";
PROGMEM const char EntryResetNote1[] =
  "\n\tThis will reset ONLY this entry.\n";
PROGMEM const char EntryResetNote2[] = "";

PROGMEM const char EEchangeWARN1[] = "\n\tEEPROM values changed\n";
PROGMEM const char EEchangeWARN2[] = "\tRESET device for changes to take effect\n";
PROGMEM const char EEchangeWARN3[] =
  "\tDevice may behave strangely until RESET\n\n";
PROGMEM const char EEchangeEVal[] = "\n\tNew value = ";
PROGMEM const char needEEmanager[] =
  "\n\tEE Manager is required to change this entry";

PROGMEM const char PedantWarn1[] = "\nTHIS WILL DESTROY PREVIOUS VALUES\n";
PROGMEM const char PedantWarn2[] = "\n\tConfirm (you have to type \"Yes\"): ";

PROGMEM const char BadDataType[] = "\n\tTIDTWIKA Bad Data Type\n";
PROGMEM const char EEPROMcorrupt[] =
	"\n\tEEPROM is inconsistent\nRESET now and RE-BURN EEPROM\n\n";
PROGMEM const char PauseBootMSG[] =
	"\nEnter something within 5 seconds to pause boot";
PROGMEM const char BootSerialReset[] =
	"\nRESET the serial line speed to the FACTORY setting of ";
PROGMEM const char BootSerialSet[] =
	"\nSet the serial line speed to 8 (9600 bps)?";
PROGMEM const char NoFactory[] =
	"\n\nNO FACTORY SETTINGS FOUND";
PROGMEM const char ReFlashNow[] =
	"\n\nCheck firmware and re-flash if necessary";
PROGMEM const char SpeedChanged[] =
	"\nSerial line speed changed in EEPROM to ";
PROGMEM const char SpeedChangedPost[] =
	"\nLine speed changes shortly\n";
PROGMEM const char SpeedChangedDummy[] =
	"\nYou MUST CHANGE YOUR CONNECTION SPEED\n\n";

// Web Headers
PROGMEM const char HttpReplyHdr[] =
    "HTTP/1.1 200 OK\nContent-Type: text/html\n\n";
PROGMEM const char HtmlStarts[] = "<html><body>\n";
PROGMEM const char HtmlEnds[] = "</body></html>\n";


/* PROGMEM definitions for dictionary burn */
PROGMEM const char pll_SerialSpd[]	 = ll_SerialSpd;
PROGMEM const char pll_Version[]	 = ll_Version;
PROGMEM const char pll_Revision[]	 = ll_Revision;
PROGMEM const char pll_Release[]	 = ll_Release;
PROGMEM const char pll_MyMAC[]		 = ll_MyMAC;
PROGMEM const char pll_MyIPdhcp[]	 = ll_MyIPdhcp;
PROGMEM const char pll_MyIP[]		 = ll_MyIP;
PROGMEM const char pll_MyNetMask[]	 = ll_MyNetMask;
PROGMEM const char pll_MyGwIP[] 	 = ll_MyGwIP;
PROGMEM const char pll_MyDnsSrv[]	 = ll_MyDnsSrv;
PROGMEM const char pll_MyUdpPort[]	 = ll_MyUdpPort;
PROGMEM const char pll_SNTPdhcp[]	 = ll_SNTPdhcp;
PROGMEM const char pll_SNTPsrvIP[]	 = ll_SNTPsrvIP;
PROGMEM const char pll_SNTPsrvPort[]	 = ll_SNTPsrvPort;
PROGMEM const char pll_UTCoffset[]	 = ll_UTCoffset;
PROGMEM const char pll_SNTPtryDNS[]	 = ll_SNTPtryDNS;
PROGMEM const char pll_SNTPpubNum[]	 = ll_SNTPpubNum;
PROGMEM const char pll_SNTPpub0[]	 = ll_SNTPpub0;
PROGMEM const char pll_SNTPpub1[]	 = ll_SNTPpub1;
PROGMEM const char pll_SNTPpub2[]	 = ll_SNTPpub2;
PROGMEM const char pll_SNTPpub3[]	 = ll_SNTPpub3;
PROGMEM const char pll_LogSrvDhcp[]	 = ll_LogSrvDhcp;
PROGMEM const char pll_LogSrvIP[]	 = ll_LogSrvIP;
PROGMEM const char pll_LogSrvPort[]	 = ll_LogSrvPort;
PROGMEM const char pll_SysFacility[]	 = ll_SysFacility;
PROGMEM const char pll_SysAlarm[]	 = ll_SysAlarm;
PROGMEM const char pll_SysWarn[]	 = ll_SysWarn;
PROGMEM const char pll_SysNormal[]	 = ll_SysNormal;
PROGMEM const char pll_SysInfo[]	 = ll_SysInfo;
PROGMEM const char pll_SysName[]	 = ll_SysName;
PROGMEM const char pll_DrawerInst[]	 = ll_DrawerInst;
PROGMEM const char pll_DrawerSwitches[]	 = ll_DrawerSwitches;
PROGMEM const char pll_BeepOpen[]	 = ll_BeepOpen;
PROGMEM const char pll_KeyOpen[]	 = ll_KeyOpen;
PROGMEM const char pll_RemindClose[]	 = ll_RemindClose;
PROGMEM const char pll_RemindDelay[]	 = ll_RemindDelay;
PROGMEM const char pll_AlarmCable[]	 = ll_AlarmCable;
PROGMEM const char pll_CtrlSrvIP[]	 = ll_CtrlSrvIP;
PROGMEM const char pll_CtrlSrvMAC[]	 = ll_CtrlSrvMAC;
PROGMEM const char pll_CtrlSrvPort[]	 = ll_CtrlSrvPort;
PROGMEM const char pll_MyListen[]	 = ll_MyListen;
