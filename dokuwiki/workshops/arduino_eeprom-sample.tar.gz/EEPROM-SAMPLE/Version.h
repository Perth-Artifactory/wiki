/*
 CashDrawer Server

 Copyright (C) 2012 Bernd Felsche, Innovative Reckoning,
 	Perth, Western Australia

 Software and memory version numbers

*/

/* ******************************************************
 *
 *	Version.Revision.Release
 *
 *	These bytes are used by the firmware to decide
 *	if the EEPROM-stored configuration data are usable
 *	by the firmware running.
 *
 *	A copy of the triplet is stored in the configuration
 *	EEPROM area, but the reliable one is stored in the
 *	factory defaults also residing in EEPROM.
 *
 *	If Version.Revision in configuration and factory
 *	defaults differs, the EEPROM is corrupted or the
 *	firmware is hopelessly inadequate.
 *
 *	Version.Revision.Release is "burned in" when
 *	factory defaults are initialised by a corresponding
 *	Version.Revision.Release of the firmware.
 *
 *	When Version.Revision in the EEPROM factory defaults 
 *	don't match that of the firmware, then the data can
 *	NOT be used safely by that firmware.
 *
 *	ONLY the Release number may differ; even in EEPROM
 *	between stored factory defaults and the configuration.
 *
 * Firmware boot checks:
 *  Is expected factory default base value magic?
 *  N -> Offer initialise factory defaults or load old firmware
 *       with likely version.revision taken from config space
 *
 *  Does EEPROM factory's version.revision match firmware?
 *  N -> Offer initialise new factory defaults or load old firmware
 *
 *  *** NB initialising required the CashDrawrEE utility.
 *
 *      It's a large process (2+kbyte) that can also
 *      burn in the data dictionary.
 *
 *      The data dictionary is required to facilitate editing of
 *      EEPROM config values.
 *
 *  Do version.revision match factory's in config space?
 *  N-> Offer to set config to factory defaults or ...
 */

#define ThisVersion	255
#define ThisRevision	255
#define	ThisRelease	255
